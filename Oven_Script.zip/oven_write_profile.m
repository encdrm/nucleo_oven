% 프로필 plot, 출력 간격
function [time_top, temp_top, time_bottom, temp_bottom] = oven_write_profile(oven_handler, x_top, y_top, x_bottom, y_bottom, interval)
    % 똑같은 x값 interval로 진행하도록 그래프 후처리하고 전송
    refresh
    out_buffer = "";
    time_top = x_top(1):interval:x_top(length(x_top));
    temp_top = spline(x_top,y_top,time_top);
    time_bottom = x_bottom(1):interval:x_bottom(length(x_bottom));
    temp_bottom = spline(x_bottom,y_bottom,time_bottom);

    % Setting top heat profile
    out_buffer = out_buffer + "T";
    for i = 1:length(time_top)
        out_buffer = out_buffer + compose("%.1f/%.1f/",single(time_top(i)), single(temp_top(i)));
    end

    % Setting bottom heat profile
    out_buffer = out_buffer + "B";
    for i = 1:length(time_bottom)
        out_buffer = out_buffer + compose("%.1f/%.1f/",single(time_bottom(i)), single(temp_bottom(i)));
    end

    % End flag
    out_buffer = out_buffer + "E";

    disp(out_buffer);
    addpoints(oven_handler.UserData.graphTop, time_top, temp_top);
    addpoints(oven_handler.UserData.graphBottom, time_bottom, temp_bottom);
    xlabel("time(s)");
    ylabel("Temperture(°C)");
    title("profile");
    write(oven_handler, out_buffer); 
end