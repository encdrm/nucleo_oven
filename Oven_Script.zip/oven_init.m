function oven_handler = oven_init()
% Connect to oven & register oven temp interrupt
    oven_handler = bluetooth("Smart_Oven", 1);
    oven_handler.UserData.tempTime = [];
    oven_handler.UserData.tempTop = [];
    oven_handler.UserData.tempBottom = [];
    subplot(1,2,1);
    oven_handler.UserData.graphTop = animatedline;
    subplot(1,2,2);
    oven_handler.UserData.graphBottom = animatedline;
    configureTerminator(oven_handler,"LF");
    configureCallback(oven_handler,"terminator", @oven_tempcallback);
end