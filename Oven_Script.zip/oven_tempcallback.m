function oven_tempcallback(src,evt)
% 오븐에서 온도를 받아오는 Callback 함수
    src.UserData.btBuffer = readline(src);
    src.UserData.temp = split(src.UserData.btBuffer, '/', 3);

    src.UserData.tempTime = [src.UserData.tempTime, str2double(src.UserData.temp(1))];
    src.UserData.tempTop = [src.UserData.tempTop, str2double(src.UserData.temp(2))];
    src.UserData.tempBottom = [src.UserData.tempBottom, str2double(src.UserData.temp(3))];

    addpoints(src.UserData.graphTop, str2double(src.UserData.temp(1)), str2double(src.UserData.temp(2)));
    drawnow
    addpoints(src.UserData.graphBottom, str2double(src.UserData.temp(1)), str2double(src.UserData.temp(3)));
    drawnow

    %tempdata = split(src.UserData.btBuffer, ",");
    %src.tempTop = [src.tempTop, tempdata(1)];
    %src.tempBottom = [src.tempTop, tempdata(1)];
end